package com.example.recyclerdemo1.activity.model

data class ProductModel(
    var name: String = "",
    var description: String = "",
    var price: Double = 0.0
)