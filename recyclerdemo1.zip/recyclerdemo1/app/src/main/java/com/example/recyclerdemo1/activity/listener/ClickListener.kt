package com.example.recyclerdemo1.activity.listener

interface ClickListener{
    fun onClick(position: Int)
}