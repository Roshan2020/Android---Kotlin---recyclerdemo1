package com.example.recyclerdemo1.activity.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.recyclerdemo1.activity.listener.ClickListener
import com.example.recyclerdemo1.activity.model.ProductModel
import com.example.recyclerdemo1.databinding.ItemProductBinding

class ProductAdapter (var context: Context, var listener: ClickListener) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>(){
    var binding: ItemProductBinding? = null
    var product = ArrayList<ProductModel>()
    inner class ProductViewHolder (var itemView: ItemProductBinding): ViewHolder(itemView.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        var inflater = LayoutInflater.from(parent.context)
        binding = ItemProductBinding.inflate(inflater, parent,false)
        return ProductViewHolder(binding!!)
    }

    override fun getItemCount(): Int {
        return product.size
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        binding!!.tvName.text = product[position].name
        binding!!.tvPrice.text = product[position].price.toString()
        binding!!.tvDescription.text = product[position].description
        binding!!.btnCart.setOnClickListener{listener.onClick(position)}
    }

    fun update(list: ArrayList<ProductModel>){
        product = list
        notifyDataSetChanged()
    }

}