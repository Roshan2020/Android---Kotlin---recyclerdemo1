package com.example.recyclerdemo1.activity

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import com.example.recyclerdemo1.R
import com.example.recyclerdemo1.activity.adapter.ProductAdapter
import com.example.recyclerdemo1.activity.listener.ClickListener
import com.example.recyclerdemo1.activity.model.ProductModel
import com.example.recyclerdemo1.databinding.ActivityMainBinding
import com.example.recyclerdemo1.databinding.ItemProductBinding

class MainActivity : AppCompatActivity(), ClickListener{
    var binding: ActivityMainBinding? = null
    var productAdapter: ProductAdapter? = null
    var product = arrayListOf<ProductModel>(
        ProductModel("laptop","this is a windows laptop",10000.0),
        ProductModel("macbook","this is a macbook",20000.0),
        ProductModel("chromebook","this is a chromebook",15000.0),
        )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        productAdapter = ProductAdapter(this, this)
        binding!!.rvProduct.adapter = productAdapter
        productAdapter!!.update(product)
    }

    override fun onClick(position: Int) {
        Toast.makeText(this,"Item no. ${position +1} is clicked", Toast.LENGTH_SHORT).show()
    }



}